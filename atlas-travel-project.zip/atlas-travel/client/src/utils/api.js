const BASE_URL = process.env.REACT_APP_API_URL || '/api';

const getHeaders = () => {
  const token = localStorage.getItem('atlas_token');
  return {
    'Content-Type': 'application/json',
    ...(token && { Authorization: `Bearer ${token}` })
  };
};

const handleResponse = async (res) => {
  const data = await res.json();
  if (!res.ok) throw new Error(data.message || 'Request failed');
  return data;
};

// Auth
export const authAPI = {
  register: (data) =>
    fetch(`${BASE_URL}/auth/register`, { method: 'POST', headers: getHeaders(), body: JSON.stringify(data) }).then(handleResponse),
  login: (data) =>
    fetch(`${BASE_URL}/auth/login`, { method: 'POST', headers: getHeaders(), body: JSON.stringify(data) }).then(handleResponse),
  getMe: () =>
    fetch(`${BASE_URL}/auth/me`, { headers: getHeaders() }).then(handleResponse),
  toggleWishlist: (id) =>
    fetch(`${BASE_URL}/auth/wishlist/${id}`, { method: 'POST', headers: getHeaders() }).then(handleResponse)
};

// Destinations
export const destinationsAPI = {
  getAll: (params = {}) => {
    const q = new URLSearchParams(params).toString();
    return fetch(`${BASE_URL}/destinations?${q}`, { headers: getHeaders() }).then(handleResponse);
  },
  getFeatured: () =>
    fetch(`${BASE_URL}/destinations/featured`, { headers: getHeaders() }).then(handleResponse),
  getById: (id) =>
    fetch(`${BASE_URL}/destinations/${id}`, { headers: getHeaders() }).then(handleResponse)
};

// Packages
export const packagesAPI = {
  getAll: (params = {}) => {
    const q = new URLSearchParams(params).toString();
    return fetch(`${BASE_URL}/packages?${q}`, { headers: getHeaders() }).then(handleResponse);
  },
  getFeatured: () =>
    fetch(`${BASE_URL}/packages/featured`, { headers: getHeaders() }).then(handleResponse),
  getById: (id) =>
    fetch(`${BASE_URL}/packages/${id}`, { headers: getHeaders() }).then(handleResponse)
};

// Bookings
export const bookingsAPI = {
  create: (data) =>
    fetch(`${BASE_URL}/bookings`, { method: 'POST', headers: getHeaders(), body: JSON.stringify(data) }).then(handleResponse),
  getMyBookings: () =>
    fetch(`${BASE_URL}/bookings/my`, { headers: getHeaders() }).then(handleResponse),
  trackBooking: (ref) =>
    fetch(`${BASE_URL}/bookings/${ref}`, { headers: getHeaders() }).then(handleResponse)
};
