import React, { useState, useEffect, useRef, useCallback } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { destinationsAPI, packagesAPI } from './utils/api';
import Navbar from './components/Navbar';
import SearchBar from './components/SearchBar';
import DestinationCard, { DestinationCardSkeleton } from './components/DestinationCard';
import PackageCard, { PackageCardSkeleton } from './components/PackageCard';
import BookingForm from './components/BookingForm';
import AuthModal from './components/AuthModal';
import Footer from './components/Footer';
import './index.css';
import './App.css';

// ── Mock data (used until backend is connected) ─────────────────────────────
const MOCK_DESTINATIONS = [
  { _id:'1', nameAr:'إسطنبول', countryAr:'تركيا', continent:'asia',
    priceFrom:8500, duration:'7 أيام', rating:4.96, reviewCount:230,
    badge:'الأكثر طلباً', emoji:'🕌', flag:'🇹🇷', bgColor:'linear-gradient(135deg,#8b2500,#d4380d)' },
  { _id:'2', nameAr:'دبي', countryAr:'الإمارات', continent:'middle-east',
    priceFrom:6200, duration:'5 أيام', rating:4.89, reviewCount:185,
    badge:'عرض خاص', emoji:'🏙️', flag:'🇦🇪', bgColor:'linear-gradient(135deg,#005a8b,#0090d4)' },
  { _id:'3', nameAr:'باريس', countryAr:'فرنسا', continent:'europe',
    priceFrom:10500, duration:'6 أيام', rating:4.93, reviewCount:147,
    emoji:'🗼', flag:'🇫🇷', bgColor:'linear-gradient(135deg,#5b2c6f,#8e44ad)' },
  { _id:'4', nameAr:'بالي', countryAr:'إندونيسيا', continent:'asia',
    priceFrom:12000, duration:'9 أيام', rating:4.88, reviewCount:120,
    emoji:'🌴', flag:'🇮🇩', bgColor:'linear-gradient(135deg,#0d6e2a,#1db954)' },
  { _id:'5', nameAr:'روما', countryAr:'إيطاليا', continent:'europe',
    priceFrom:9200, duration:'6 أيام', rating:4.91, reviewCount:98,
    emoji:'🏛️', flag:'🇮🇹', bgColor:'linear-gradient(135deg,#8b4a00,#d4840d)' },
  { _id:'6', nameAr:'مراكش', countryAr:'المغرب', continent:'morocco',
    priceFrom:1800, duration:'3 أيام', rating:4.85, reviewCount:210,
    badge:'محلي', emoji:'🏔️', flag:'🇲🇦', bgColor:'linear-gradient(135deg,#0d5c63,#12857c)' },
];

const MOCK_PACKAGES = [
  { _id:'p1', titleAr:'رحلة تركيا 7 أيام', citiesAr:['إسطنبول','كابادوكيا','أنطاليا'],
    price:8500, rating:4.96, reviewCount:230, badge:'🔥 الأكثر مبيعاً', badgeColor:'#ff385c',
    emoji:'🌙', bgColor:'linear-gradient(135deg,#7b1a00,#d43b0d)',
    includes:['طيران شامل','فندق 4 نجوم','نقل'] },
  { _id:'p2', titleAr:'رحلة دبي 5 أيام', citiesAr:['دبي'],
    price:6200, rating:4.89, reviewCount:185, badge:'⭐ ممتاز', badgeColor:'#2563eb',
    emoji:'🏙️', bgColor:'linear-gradient(135deg,#003a66,#0066b3)',
    includes:['طيران شامل','فندق 5 نجوم','جولات'] },
  { _id:'p3', titleAr:'رحلة إسبانيا 8 أيام', citiesAr:['برشلونة','مدريد','غرناطة'],
    price:9800, originalPrice:11500, rating:4.92, reviewCount:112, badge:'✨ جديد', badgeColor:'#16a34a',
    emoji:'⛪', bgColor:'linear-gradient(135deg,#0a4a20,#1a8a40)',
    includes:['طيران شامل','فندق 4 نجوم','نقل'] },
  { _id:'p4', titleAr:'رحلات المغرب', citiesAr:['مراكش','أكادير','مرزوقة'],
    price:1800, rating:4.85, reviewCount:201, badge:'💎 VIP', badgeColor:'#7c3aed',
    emoji:'🌴', bgColor:'linear-gradient(135deg,#4a0d6b,#8b2fc9)',
    includes:['نقل مريح','رياض أصيل','جولات'] },
];

const CONTINENTS = [
  { key:'all', label:'🌍 الكل' },
  { key:'asia', label:'🌏 آسيا' },
  { key:'europe', label:'🇪🇺 أوروبا' },
  { key:'middle-east', label:'🕌 الشرق الأوسط' },
  { key:'morocco', label:'🇲🇦 المغرب' },
];

// ── Scroll reveal hook ───────────────────────
const useReveal = () => {
  useEffect(() => {
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1 });

    document.querySelectorAll('.reveal').forEach(el => observer.observe(el));
    return () => observer.disconnect();
  });
};

// ── Toast hook ───────────────────────────────
const useToast = () => {
  const [toast, setToast] = useState(null);
  const show = useCallback((msg) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  }, []);
  return { toast, show };
};

// ── Main App ─────────────────────────────────
const AppContent = () => {
  const { user, toggleWishlist } = useAuth();
  const { toast, show: showToast } = useToast();
  useReveal();

  const [destinations, setDestinations] = useState(MOCK_DESTINATIONS);
  const [packages, setPackages] = useState(MOCK_PACKAGES);
  const [loadingDest, setLoadingDest] = useState(false);
  const [activeContinent, setActiveContinent] = useState('all');
  const [showBooking, setShowBooking] = useState(false);
  const [selectedPackage, setSelectedPackage] = useState(null);
  const [bookingSuccess, setBookingSuccess] = useState(null);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authMode, setAuthMode] = useState('login');

  // Try to fetch from API, fall back to mock data
  useEffect(() => {
    destinationsAPI.getFeatured()
      .then(data => { if (data?.length) setDestinations(data); })
      .catch(() => {});
    packagesAPI.getFeatured()
      .then(data => { if (data?.length) setPackages(data); })
      .catch(() => {});
  }, []);

  // Filter destinations
  const filteredDests = activeContinent === 'all'
    ? destinations
    : destinations.filter(d => d.continent === activeContinent);

  const handleWishlist = async (id, adding) => {
    if (!user) {
      setAuthMode('login');
      setShowAuthModal(true);
      return;
    }
    await toggleWishlist(id);
    showToast(adding ? '❤️ تمت الإضافة لقائمة أمنياتك' : '💔 تمت الإزالة من قائمة أمنياتك');
  };

  const handleBook = (pkg = null) => {
    setSelectedPackage(pkg);
    setShowBooking(true);
  };

  const handleBookingSuccess = (ref) => {
    setShowBooking(false);
    setBookingSuccess(ref);
    showToast(`✅ تم الحجز! رقم مرجعك: ${ref}`);
  };

  const scrollTo = id => document.getElementById(id)?.scrollIntoView({ behavior:'smooth' });

  return (
    <div className="app">
      {toast && <div className="toast">{toast}</div>}

      <Navbar onBookNow={() => handleBook()} />

      {/* ═══ HERO ═══ */}
      <section className="hero-section" id="hero">
        <div className="hero-bg">
          {/*
            📸 HERO IMAGE PLACEHOLDER
            ضع هنا صورة جوية لمدينة أو شاطئ جميل
            مثال: إسطنبول من الجو، أو شاطئ بالي
            اسم الملف: hero-bg.jpg
            المقاس: 1920×1080px
            استخدم: background-image: url('/hero-bg.jpg')
          */}
        </div>
        <div className="hero-overlay" />

        <div className="hero-content container">
          <div className="hero-text reveal">
            <div className="hero-badge">
              <span className="badge-dot" />
              وكالة سفر موثوقة منذ 2015
            </div>
            <h1>
              ابحث عن <em>رحلتك المثالية</em><br />
              واحجز بثقة كاملة
            </h1>
            <p>أكثر من 120 وجهة سياحية — تنظيم احترافي من البداية حتى العودة</p>
            <div className="hero-btns">
              <button className="btn btn-primary btn-lg" onClick={() => scrollTo('destinations')}>
                🌍 استكشف الوجهات
              </button>
              <button className="btn btn-ghost btn-lg" onClick={() => handleBook()}>
                احجز رحلتك الآن
              </button>
            </div>
          </div>

          <div className="hero-search-wrap reveal">
            <SearchBar onSearch={(form) => {
              showToast('🔍 جاري البحث عن أفضل العروض...');
              scrollTo('packages');
            }} />
          </div>
        </div>

        {/* Stats */}
        <div className="hero-stats">
          <div className="hero-stat"><strong>120+</strong><span>وجهة سياحية</span></div>
          <div className="hero-stat-div" />
          <div className="hero-stat"><strong>500+</strong><span>رحلة منجزة</span></div>
          <div className="hero-stat-div" />
          <div className="hero-stat"><strong>98%</strong><span>رضا العملاء</span></div>
          <div className="hero-stat-div" />
          <div className="hero-stat"><strong>10+</strong><span>سنوات خبرة</span></div>
        </div>
      </section>

      {/* ═══ TRUST ═══ */}
      <section className="trust-section section-sm">
        <div className="container">
          <div className="trust-grid reveal">
            {[
              { icon:'✅', title:'احجز بثقة كاملة', desc:'دعم 24/7 وآراء موثوقة من عملائنا في كل رحلة.' },
              { icon:'🌍', title:'120+ وجهة سياحية', desc:'اكتشف الوجهات الأنسب لميزانيتك وتفضيلاتك.' },
              { icon:'🔄', title:'إلغاء مجاني مرن', desc:'غير خططك بسهولة — سياسة إلغاء واضحة وعادلة.' },
            ].map((t, i) => (
              <div key={i} className="trust-item">
                <span className="trust-icon">{t.icon}</span>
                <div>
                  <div className="trust-title">{t.title}</div>
                  <div className="trust-desc">{t.desc}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ═══ DESTINATIONS ═══ */}
      <section className="section" id="destinations">
        <div className="container">
          <div className="sec-header reveal">
            <div className="sec-header-left">
              <h2>أشهر الوجهات</h2>
              <p>اختر وجهتك واحجز بكل سهولة</p>
            </div>
            <div className="sec-header-right hide-mobile">
              <button className="btn btn-outline btn-sm" onClick={() => scrollTo('booking')}>
                عرض الكل
              </button>
            </div>
          </div>

          {/* Filters */}
          <div className="filters reveal">
            {CONTINENTS.map(c => (
              <button
                key={c.key}
                className={`filter-chip ${activeContinent === c.key ? 'active' : ''}`}
                onClick={() => setActiveContinent(c.key)}
              >
                {c.label}
              </button>
            ))}
          </div>

          <div className="h-scroll reveal">
            {loadingDest
              ? Array(5).fill(0).map((_, i) => <DestinationCardSkeleton key={i} />)
              : filteredDests.map(dest => (
                  <DestinationCard
                    key={dest._id}
                    destination={dest}
                    onWishlistClick={handleWishlist}
                    onBookClick={() => handleBook()}
                  />
                ))
            }
          </div>
        </div>
      </section>

      {/* ═══ PACKAGES ═══ */}
      <section className="section packages-section" id="packages">
        <div className="container">
          <div className="sec-header reveal">
            <div className="sec-header-left">
              <h2>عروض حصرية</h2>
              <p>باقات شاملة بأسعار مميزة — طيران + فندق + نقل</p>
            </div>
            <div className="sec-header-right hide-mobile">
              <div className="filters" style={{ margin:0 }}>
                <button className="filter-chip active">💰 الكل</button>
                <button className="filter-chip">أقل من 5000</button>
                <button className="filter-chip">5000 - 10000</button>
              </div>
            </div>
          </div>

          <div className="h-scroll reveal">
            {packages.map(pkg => (
              <PackageCard
                key={pkg._id}
                pkg={pkg}
                onBook={p => handleBook(p)}
              />
            ))}
          </div>
        </div>
      </section>

      {/* ═══ EXPERIENCES ═══ */}
      <section className="section" id="experiences">
        <div className="container">
          <div className="sec-header reveal">
            <div className="sec-header-left">
              <h2>الأنشطة السياحية</h2>
              <p>تجارب لا تُنسى تضيف لرحلتك نكهة مختلفة</p>
            </div>
          </div>
          <div className="h-scroll reveal">
            {[
              { icon:'🎈', name:'منطاد كابادوكيا', price:'1,200', bg:'linear-gradient(135deg,#3a006b,#7928ca)' },
              { icon:'🤿', name:'غوص في البحر الأحمر', price:'800', bg:'linear-gradient(135deg,#005280,#0090c8)' },
              { icon:'🏜️', name:'سفاري صحراء دبي', price:'650', bg:'linear-gradient(135deg,#6b3a00,#c47000)' },
              { icon:'⛵', name:'رحلة بحرية في بالي', price:'550', bg:'linear-gradient(135deg,#004030,#007a58)' },
              { icon:'🍲', name:'درس طبخ مغربي', price:'350', bg:'linear-gradient(135deg,#5a0000,#a30000)' },
            ].map((exp, i) => (
              <div key={i} className="exp-card">
                <div className="exp-img-wrap">
                  <div className="exp-img" style={{ background: exp.bg }}>
                    {/*
                      📸 صورة النشاط السياحي
                      اسم الملف: activity-{i+1}.jpg
                      استبدل الـ emoji بصورة حقيقية
                    */}
                    <span className="exp-emoji">{exp.icon}</span>
                  </div>
                </div>
                <div className="exp-name">{exp.name}</div>
                <div className="exp-price">من <strong>{exp.price}</strong> درهم</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ═══ PARTNERS ═══ */}
      <section className="partners-section section-sm">
        <div className="container">
          <p className="partners-label reveal">شركاؤنا الموثوقون</p>
          <div className="partners-row reveal">
            {['✈️ Emirates','✈️ Qatar Airways','✈️ Royal Air Maroc','🏨 Hilton','🏨 Marriott','🔵 Booking.com'].map((p,i) => (
              <div key={i} className="partner">{p}</div>
            ))}
          </div>
        </div>
      </section>

      {/* ═══ REVIEWS ═══ */}
      <section className="section" id="reviews">
        <div className="container">
          <div className="sec-header reveal">
            <div className="sec-header-left">
              <h2>ماذا يقول عملاؤنا</h2>
              <p>تجارب حقيقية من مسافرين اختاروا Atlas Travel</p>
            </div>
          </div>
          <div className="h-scroll reveal">
            {[
              { name:'سارة المنصوري', from:'الدار البيضاء', date:'مارس 2025', avatar:'👩', color:'#d5a6f0', text:'رحلة تركيا كانت أحسن تجربة في حياتي — التنظيم ممتاز من البداية للنهاية.' },
              { name:'أحمد بنعلي', from:'مراكش', date:'فبراير 2025', avatar:'👨', color:'#85c1e9', text:'سافرت مع عائلتي إلى دبي وكان كل شيء مثالياً. أسعار معقولة وخدمة راقية.' },
              { name:'فاطمة الزهراء', from:'الرباط', date:'يناير 2025', avatar:'👩', color:'#82e0aa', text:'خدمة ممتازة وفريق محترف. شاركت تجربتي مع أصدقائي وكلهم سافروا معهم.' },
              { name:'يوسف العلوي', from:'فاس', date:'ديسمبر 2024', avatar:'👨', color:'#f9ca74', text:'من أفضل الوكالات — الرحلة منظمة بشكل رائع والسعر في متناول الجميع.' },
            ].map((r, i) => (
              <div key={i} className="review-card card">
                <div className="review-stars">★★★★★</div>
                <p className="review-text">"{r.text}"</p>
                <div className="review-author">
                  <div className="review-av" style={{ background: r.color }}>{r.avatar}</div>
                  <div>
                    <div className="review-name">{r.name}</div>
                    <div className="review-date">{r.date} · {r.from}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ═══ FAQ ═══ */}
      <section className="faq-section section" id="faq">
        <div className="container">
          <div className="sec-header reveal">
            <div className="sec-header-left">
              <h2>أسئلتك، إجاباتها</h2>
            </div>
          </div>
          <FaqList />
        </div>
      </section>

      {/* ═══ BOOKING SECTION ═══ */}
      <section className="section cta-section" id="booking">
        <div className="container">
          <div className="cta-inner reveal">
            <div className="cta-glow" />
            <h2>جاهز تحجز <em>رحلة الأحلام؟</em> 🌍</h2>
            <p>تواصل معنا الآن وسنرتب لك رحلة لا تُنسى<br />بأفضل سعر وأعلى مستوى من الخدمة</p>
            <div className="cta-btns">
              <button className="btn btn-primary btn-lg" onClick={() => handleBook()}>
                ✈️ احجز الآن
              </button>
              <a
                href="https://wa.me/212600000000"
                target="_blank"
                rel="noreferrer"
                className="btn btn-wa btn-lg"
              >
                💬 واتساب
              </a>
            </div>
          </div>
        </div>
      </section>

      <Footer />

      {/* Floating WhatsApp */}
      <a href="https://wa.me/212600000000" target="_blank" rel="noreferrer" className="wa-float" aria-label="واتساب">
        💬
        <span className="wa-tooltip">احجز على واتساب</span>
      </a>

      {/* Booking success */}
      {bookingSuccess && (
        <div className="modal-overlay" onClick={() => setBookingSuccess(null)}>
          <div className="modal-box success-modal">
            <div className="success-icon">🎉</div>
            <h2>تم الحجز بنجاح!</h2>
            <p>رقمك المرجعي:</p>
            <div className="booking-ref">{bookingSuccess}</div>
            <p className="success-sub">سيتواصل معك فريقنا خلال 24 ساعة لتأكيد التفاصيل.</p>
            <button className="btn btn-primary" style={{ width:'100%', justifyContent:'center', marginTop:20 }} onClick={() => setBookingSuccess(null)}>
              رائع، شكراً!
            </button>
          </div>
        </div>
      )}

      {/* Modals */}
      {showBooking && (
        <BookingForm
          selectedPackage={selectedPackage}
          onSuccess={handleBookingSuccess}
          onClose={() => setShowBooking(false)}
        />
      )}
      {showAuthModal && (
        <AuthModal
          mode={authMode}
          onClose={() => setShowAuthModal(false)}
          onSwitchMode={() => setAuthMode(m => m === 'login' ? 'register' : 'login')}
        />
      )}
    </div>
  );
};

// ── FAQ Component ────────────────────────────
const FAQS = [
  { q:'كيف تعمل وكالة Atlas Travel؟', a:'نحن وكالة سفر متخصصة في تنظيم الرحلات من المغرب إلى أكثر من 120 وجهة عالمية. نوفر الطيران والإقامة والنقل والجولات بسعر شامل وشفاف.' },
  { q:'كيف أحجز رحلتي؟', a:'اضغط على "احجز الآن" أو تواصل معنا عبر واتساب. سيرد عليك مستشار متخصص خلال 24 ساعة لتأكيد التفاصيل والسعر النهائي.' },
  { q:'هل يمكنني إلغاء الحجز؟', a:'نعم، نوفر سياسة إلغاء مرنة. التفاصيل ستكون واضحة في عقد الحجز قبل أي دفع.' },
  { q:'ما الذي يشمله سعر الرحلة؟', a:'تشمل باقاتنا تذاكر الطيران ذهاباً وإياباً، الإقامة الفندقية، النقل من وإلى المطار، وجولات سياحية منتقاة.' },
];

const FaqList = () => {
  const [open, setOpen] = useState(null);
  return (
    <div className="faq-list reveal">
      {FAQS.map((f, i) => (
        <div key={i} className={`faq-item ${open === i ? 'open' : ''}`}>
          <button className="faq-q" onClick={() => setOpen(open === i ? null : i)}>
            {f.q}
            <span className="faq-arrow">▾</span>
          </button>
          <div className="faq-a">{f.a}</div>
        </div>
      ))}
    </div>
  );
};

// ── Root ─────────────────────────────────────
const App = () => (
  <AuthProvider>
    <AppContent />
  </AuthProvider>
);

export default App;
