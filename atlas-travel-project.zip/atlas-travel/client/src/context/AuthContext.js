import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { authAPI } from '../utils/api';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  const loadUser = useCallback(async () => {
    const token = localStorage.getItem('atlas_token');
    if (!token) { setLoading(false); return; }
    try {
      const data = await authAPI.getMe();
      setUser(data);
    } catch {
      localStorage.removeItem('atlas_token');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadUser(); }, [loadUser]);

  const login = async (email, password) => {
    const data = await authAPI.login({ email, password });
    localStorage.setItem('atlas_token', data.token);
    setUser(data.user);
    return data;
  };

  const register = async (name, email, password, phone) => {
    const data = await authAPI.register({ name, email, password, phone });
    localStorage.setItem('atlas_token', data.token);
    setUser(data.user);
    return data;
  };

  const logout = () => {
    localStorage.removeItem('atlas_token');
    setUser(null);
  };

  const toggleWishlist = async (destinationId) => {
    if (!user) return false;
    try {
      const data = await authAPI.toggleWishlist(destinationId);
      setUser(prev => ({ ...prev, wishlist: data.wishlist }));
      return true;
    } catch { return false; }
  };

  const isInWishlist = (destinationId) => {
    if (!user || !user.wishlist) return false;
    return user.wishlist.some(id =>
      (typeof id === 'object' ? id._id : id) === destinationId
    );
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout, toggleWishlist, isInWishlist }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
