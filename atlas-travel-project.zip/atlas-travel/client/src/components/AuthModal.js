import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import './AuthModal.css';

const AuthModal = ({ mode, onClose, onSwitchMode }) => {
  const { login, register } = useAuth();
  const [form, setForm] = useState({ name:'', email:'', password:'', phone:'' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const isLogin = mode === 'login';

  const handleChange = e => {
    setForm(prev => ({ ...prev, [e.target.name]: e.target.value }));
    setError('');
  };

  const handleSubmit = async e => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      if (isLogin) {
        await login(form.email, form.password);
      } else {
        await register(form.name, form.email, form.password, form.phone);
      }
      onClose();
    } catch (err) {
      setError(err.message || 'حدث خطأ، حاول مجدداً');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal-box auth-modal">
        <div className="modal-header">
          <div className="modal-logo">✈️ Atlas Travel</div>
          <button className="modal-close" onClick={onClose}>✕</button>
        </div>

        <h2 className="modal-title">
          {isLogin ? 'مرحباً بعودتك 👋' : 'إنشاء حساب جديد'}
        </h2>
        <p className="modal-sub">
          {isLogin ? 'سجّل الدخول لإدارة حجوزاتك وقائمة أمنياتك' : 'انضم لآلاف المسافرين الذين يثقون بنا'}
        </p>

        {error && <div className="auth-error">⚠️ {error}</div>}

        <form onSubmit={handleSubmit} className="auth-form">
          {!isLogin && (
            <div className="form-group">
              <label className="form-label">الاسم الكامل</label>
              <input
                className="form-input"
                type="text"
                name="name"
                placeholder="أدخل اسمك"
                value={form.name}
                onChange={handleChange}
                required
              />
            </div>
          )}

          <div className="form-group">
            <label className="form-label">البريد الإلكتروني</label>
            <input
              className="form-input"
              type="email"
              name="email"
              placeholder="example@email.com"
              value={form.email}
              onChange={handleChange}
              required
            />
          </div>

          {!isLogin && (
            <div className="form-group">
              <label className="form-label">رقم الهاتف</label>
              <input
                className="form-input"
                type="tel"
                name="phone"
                placeholder="+212 600 000 000"
                value={form.phone}
                onChange={handleChange}
              />
            </div>
          )}

          <div className="form-group">
            <label className="form-label">كلمة المرور</label>
            <input
              className="form-input"
              type="password"
              name="password"
              placeholder="••••••••"
              value={form.password}
              onChange={handleChange}
              required
              minLength={6}
            />
          </div>

          <button
            type="submit"
            className="btn btn-primary"
            style={{ width:'100%', justifyContent:'center', marginTop:8 }}
            disabled={loading}
          >
            {loading ? '⏳ جاري التحميل...' : (isLogin ? 'تسجيل الدخول' : 'إنشاء الحساب')}
          </button>
        </form>

        <div className="auth-switch">
          {isLogin ? 'ليس لديك حساب؟' : 'لديك حساب بالفعل؟'}
          <button className="auth-switch-btn" onClick={onSwitchMode}>
            {isLogin ? 'إنشاء حساب' : 'تسجيل الدخول'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default AuthModal;
