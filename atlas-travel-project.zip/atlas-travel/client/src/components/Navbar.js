import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import AuthModal from './AuthModal';
import './Navbar.css';

const Navbar = ({ onBookNow }) => {
  const { user, logout } = useAuth();
  const [scrolled, setScrolled] = useState(false);
  const [showAuth, setShowAuth] = useState(false);
  const [authMode, setAuthMode] = useState('login');
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener('scroll', handleScroll, { passive:true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollTo = (id) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior:'smooth' });
    setMenuOpen(false);
  };

  return (
    <>
      <nav className={`navbar ${scrolled ? 'scrolled' : ''}`}>
        <div className="navbar-inner">
          {/* Logo */}
          <div className="navbar-logo" onClick={() => scrollTo('hero')}>
            <span className="logo-icon">✈️</span>
            <span className="logo-text">Atlas Travel</span>
          </div>

          {/* Center tabs */}
          <div className="navbar-tabs hide-mobile">
            <button className="nav-tab" onClick={() => scrollTo('destinations')}>الوجهات</button>
            <button className="nav-tab" onClick={() => scrollTo('packages')}>العروض</button>
            <button className="nav-tab" onClick={() => scrollTo('experiences')}>التجارب</button>
            <button className="nav-tab" onClick={() => scrollTo('blog')}>المدونة</button>
          </div>

          {/* Right actions */}
          <div className="navbar-actions">
            <button className="btn btn-primary btn-sm" onClick={onBookNow}>
              احجز الآن
            </button>

            {user ? (
              <div className="user-menu">
                <button className="user-btn" onClick={() => setMenuOpen(!menuOpen)}>
                  <span className="user-avatar">
                    {user.name?.charAt(0).toUpperCase()}
                  </span>
                  <span className="hide-mobile">{user.name?.split(' ')[0]}</span>
                </button>
                {menuOpen && (
                  <div className="user-dropdown">
                    <div className="dropdown-item user-info">
                      <strong>{user.name}</strong>
                      <small>{user.email}</small>
                    </div>
                    <div className="dropdown-divider" />
                    <button className="dropdown-item" onClick={() => { scrollTo('bookings'); setMenuOpen(false); }}>
                      📋 حجوزاتي
                    </button>
                    <button className="dropdown-item" onClick={() => { scrollTo('wishlist'); setMenuOpen(false); }}>
                      ❤️ قائمة أمنياتي
                    </button>
                    <div className="dropdown-divider" />
                    <button className="dropdown-item danger" onClick={() => { logout(); setMenuOpen(false); }}>
                      🚪 تسجيل الخروج
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <button
                className="btn btn-outline btn-sm hide-mobile"
                onClick={() => { setAuthMode('login'); setShowAuth(true); }}
              >
                تسجيل الدخول
              </button>
            )}
          </div>
        </div>
      </nav>

      {showAuth && (
        <AuthModal
          mode={authMode}
          onClose={() => setShowAuth(false)}
          onSwitchMode={() => setAuthMode(m => m === 'login' ? 'register' : 'login')}
        />
      )}
    </>
  );
};

export default Navbar;
