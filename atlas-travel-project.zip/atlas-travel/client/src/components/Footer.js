import React from 'react';
import './Footer.css';

const Footer = () => {
  const scrollTo = id => document.getElementById(id)?.scrollIntoView({ behavior:'smooth' });

  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-grid">
          <div className="footer-brand">
            <div className="footer-logo">✈️ Atlas Travel</div>
            <p>وكالة سفر موثوقة منذ 2015 — أكثر من 500 رحلة ناجحة ومئات العملاء السعداء من المغرب والعالم.</p>
            <div className="footer-social">
              <a href="#instagram" className="social-btn" aria-label="Instagram">📷</a>
              <a href="#facebook"  className="social-btn" aria-label="Facebook">📘</a>
              <a href="#tiktok"    className="social-btn" aria-label="TikTok">🎵</a>
              <a href="#youtube"   className="social-btn" aria-label="YouTube">▶️</a>
            </div>
          </div>

          <div className="footer-col">
            <h4>الموقع</h4>
            <button onClick={() => scrollTo('destinations')}>الوجهات</button>
            <button onClick={() => scrollTo('packages')}>العروض</button>
            <button onClick={() => scrollTo('experiences')}>التجارب</button>
            <button onClick={() => scrollTo('blog')}>المدونة</button>
          </div>

          <div className="footer-col">
            <h4>الشركة</h4>
            <a href="#about">من نحن</a>
            <a href="#privacy">سياسة الخصوصية</a>
            <a href="#terms">الشروط والأحكام</a>
            <a href="#faq">الأسئلة الشائعة</a>
          </div>

          <div className="footer-col">
            <h4>تواصل معنا</h4>
            <a href="mailto:info@atlas-travel.ma">info@atlas-travel.ma</a>
            <a href="tel:+212600000000">+212 600 000 000</a>
            <a href="https://wa.me/212600000000" target="_blank" rel="noreferrer">واتساب</a>
            <span>الدار البيضاء، المغرب 🇲🇦</span>
          </div>
        </div>

        <div className="footer-divider" />

        <div className="footer-bottom">
          <div className="footer-copy">
            © 2025 Atlas Travel Agency — جميع الحقوق محفوظة
          </div>
          <div className="footer-bottom-links">
            <a href="#privacy">الخصوصية</a>
            <a href="#terms">الشروط</a>
            <a href="#sitemap">خريطة الموقع</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
