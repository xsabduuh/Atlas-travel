import React, { useState } from 'react';
import './SearchBar.css';

const SearchBar = ({ onSearch }) => {
  const [form, setForm] = useState({
    from: 'المغرب',
    to: '',
    date: '',
    travelers: '1'
  });

  const handleChange = e =>
    setForm(prev => ({ ...prev, [e.target.name]: e.target.value }));

  const handleSubmit = e => {
    e.preventDefault();
    onSearch && onSearch(form);
  };

  return (
    <div className="searchbar-wrap">
      <form className="searchbar-card" onSubmit={handleSubmit}>
        <div className="searchbar-fields">
          <div className="sb-field">
            <label className="sb-label">المغادرة من</label>
            <select className="sb-input" name="from" value={form.from} onChange={handleChange}>
              <option>المغرب</option>
              <option>الجزائر</option>
              <option>تونس</option>
              <option>فرنسا</option>
            </select>
          </div>

          <div className="sb-divider" />

          <div className="sb-field">
            <label className="sb-label">الوجهة</label>
            <select className="sb-input" name="to" value={form.to} onChange={handleChange}>
              <option value="">اختر الوجهة</option>
              <option>تركيا — إسطنبول</option>
              <option>دبي — الإمارات</option>
              <option>إسبانيا</option>
              <option>باريس</option>
              <option>بالي</option>
              <option>روما</option>
              <option>داخل المغرب</option>
            </select>
          </div>

          <div className="sb-divider" />

          <div className="sb-field">
            <label className="sb-label">تاريخ السفر</label>
            <input
              className="sb-input"
              type="date"
              name="date"
              value={form.date}
              onChange={handleChange}
              min={new Date().toISOString().split('T')[0]}
            />
          </div>

          <div className="sb-divider" />

          <div className="sb-field">
            <label className="sb-label">المسافرون</label>
            <select className="sb-input" name="travelers" value={form.travelers} onChange={handleChange}>
              <option value="1">1 شخص</option>
              <option value="2">2 شخص</option>
              <option value="3">3 أشخاص</option>
              <option value="4">4 أشخاص</option>
              <option value="5+">مجموعة</option>
            </select>
          </div>
        </div>

        <button type="submit" className="btn btn-primary sb-btn">
          🔍 بحث
        </button>
      </form>

      <div className="searchbar-hint">
        <span>🔒 حجز آمن</span>
        <span>·</span>
        <span>بدون دفع مسبق</span>
        <span>·</span>
        <span>إلغاء مجاني</span>
      </div>
    </div>
  );
};

export default SearchBar;
