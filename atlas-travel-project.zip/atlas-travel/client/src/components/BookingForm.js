import React, { useState } from 'react';
import { bookingsAPI } from '../utils/api';
import { useAuth } from '../context/AuthContext';
import './BookingForm.css';

const BookingForm = ({ selectedPackage, onSuccess, onClose }) => {
  const { user } = useAuth();
  const [form, setForm] = useState({
    name: user?.name || '',
    email: user?.email || '',
    phone: user?.phone || '',
    destination_name: selectedPackage?.titleAr || '',
    travelDate: '',
    travelers: 1,
    budget: '5000-10000',
    notes: ''
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleChange = e => {
    setForm(prev => ({ ...prev, [e.target.name]: e.target.value }));
    setError('');
  };

  const handleSubmit = async e => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      const payload = {
        guestInfo: { name: form.name, email: form.email, phone: form.phone },
        destination_name: form.destination_name,
        travelDate: form.travelDate,
        travelers: Number(form.travelers),
        budget: form.budget,
        notes: form.notes,
        ...(selectedPackage && { package: selectedPackage._id })
      };
      const data = await bookingsAPI.create(payload);
      onSuccess && onSuccess(data.bookingRef);
    } catch (err) {
      setError(err.message || 'حدث خطأ، حاول مجدداً');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal-box booking-modal">
        <div className="booking-modal-header">
          <div>
            <h2 className="booking-title">احجز رحلتك</h2>
            <p className="booking-sub">
              {selectedPackage ? `${selectedPackage.titleAr}` : 'أرسل طلبك وسنتواصل معك خلال 24 ساعة'}
            </p>
          </div>
          <button className="modal-close" onClick={onClose}>✕</button>
        </div>

        {error && <div className="auth-error">⚠️ {error}</div>}

        <form onSubmit={handleSubmit} className="booking-form">
          <div className="form-row-2">
            <div className="form-group">
              <label className="form-label">الاسم الكامل *</label>
              <input className="form-input" type="text" name="name" value={form.name} onChange={handleChange} placeholder="أدخل اسمك" required />
            </div>
            <div className="form-group">
              <label className="form-label">رقم الهاتف *</label>
              <input className="form-input" type="tel" name="phone" value={form.phone} onChange={handleChange} placeholder="+212 600 000 000" required />
            </div>
          </div>

          <div className="form-group">
            <label className="form-label">البريد الإلكتروني *</label>
            <input className="form-input" type="email" name="email" value={form.email} onChange={handleChange} placeholder="example@email.com" required />
          </div>

          <div className="form-row-2">
            <div className="form-group">
              <label className="form-label">الوجهة *</label>
              <select className="form-input" name="destination_name" value={form.destination_name} onChange={handleChange} required>
                <option value="">اختر الوجهة</option>
                <option>تركيا — إسطنبول</option>
                <option>دبي — الإمارات</option>
                <option>إسبانيا</option>
                <option>باريس — فرنسا</option>
                <option>بالي — إندونيسيا</option>
                <option>روما — إيطاليا</option>
                <option>داخل المغرب</option>
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">تاريخ السفر *</label>
              <input className="form-input" type="date" name="travelDate" value={form.travelDate} onChange={handleChange} required min={new Date().toISOString().split('T')[0]} />
            </div>
          </div>

          <div className="form-row-2">
            <div className="form-group">
              <label className="form-label">عدد المسافرين</label>
              <select className="form-input" name="travelers" value={form.travelers} onChange={handleChange}>
                {[1,2,3,4,5,6,7,8].map(n => (
                  <option key={n} value={n}>{n} {n === 1 ? 'شخص' : 'أشخاص'}</option>
                ))}
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">الميزانية التقريبية</label>
              <select className="form-input" name="budget" value={form.budget} onChange={handleChange}>
                <option value="under-5000">أقل من 5,000 درهم</option>
                <option value="5000-10000">5,000 - 10,000 درهم</option>
                <option value="over-10000">أكثر من 10,000 درهم</option>
              </select>
            </div>
          </div>

          <div className="form-group">
            <label className="form-label">ملاحظات إضافية</label>
            <textarea className="form-input" name="notes" value={form.notes} onChange={handleChange} placeholder="أي طلبات خاصة أو استفسارات..." rows={3} style={{ resize:'vertical' }} />
          </div>

          <div className="booking-trust">
            <span>✅ بدون دفع مسبق</span>
            <span>🔒 بيانات آمنة</span>
            <span>📞 رد خلال 24 ساعة</span>
          </div>

          <button type="submit" className="btn btn-primary btn-lg" style={{ width:'100%', justifyContent:'center' }} disabled={loading}>
            {loading ? '⏳ جاري الإرسال...' : '✈️ تأكيد طلب الحجز'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default BookingForm;
