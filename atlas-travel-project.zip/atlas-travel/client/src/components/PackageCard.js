import React from 'react';
import './PackageCard.css';

const PackageCard = ({ pkg, onBook }) => {
  const discount = pkg.originalPrice
    ? Math.round((1 - pkg.price / pkg.originalPrice) * 100)
    : null;

  return (
    <div className="pkg-card card">
      {/* Image */}
      <div className="pkg-img-wrap">
        {pkg.image ? (
          <img src={pkg.image} alt={pkg.titleAr} className="pkg-img-real" loading="lazy" />
        ) : (
          <div className="pkg-img-placeholder" style={{ background: pkg.bgColor || '#1a3a6e' }}>
            <span className="pkg-emoji">{pkg.emoji || '✈️'}</span>
          </div>
        )}
        <div className="pkg-overlay" />

        {/* Wishlist */}
        <button className="pkg-wishlist">🤍</button>

        {/* Tag */}
        {pkg.badge && (
          <div className="pkg-tag" style={{ background: pkg.badgeColor || '#ff385c' }}>
            {pkg.badge}
          </div>
        )}

        {/* Discount */}
        {discount && (
          <div className="pkg-discount">خصم {discount}%</div>
        )}
      </div>

      {/* Info */}
      <div className="pkg-info">
        <div className="pkg-head">
          <div className="pkg-title">{pkg.titleAr}</div>
          <div className="pkg-rating-inline">
            <span className="stars">★</span>
            <span>{pkg.rating?.toFixed(1)}</span>
          </div>
        </div>

        <div className="pkg-cities">
          {pkg.citiesAr?.join(' · ')}
        </div>

        <div className="pkg-includes">
          {pkg.includes?.slice(0, 3).map((inc, i) => (
            <span key={i} className="pkg-include-tag">✓ {inc}</span>
          ))}
        </div>

        <div className="pkg-footer">
          <div className="pkg-price-block">
            {pkg.originalPrice && (
              <span className="pkg-original-price">
                {pkg.originalPrice.toLocaleString()} درهم
              </span>
            )}
            <div className="pkg-price">
              <strong>{pkg.price?.toLocaleString()}</strong>
              <span>درهم / شخص</span>
            </div>
          </div>
          <button
            className="btn btn-primary btn-sm"
            onClick={() => onBook && onBook(pkg)}
          >
            احجز الآن
          </button>
        </div>
      </div>
    </div>
  );
};

export const PackageCardSkeleton = () => (
  <div className="pkg-card card">
    <div className="skeleton" style={{ height:200, borderRadius:'14px 14px 0 0' }} />
    <div style={{ padding:14 }}>
      <div className="skeleton" style={{ height:16, width:'80%', marginBottom:10 }} />
      <div className="skeleton" style={{ height:12, width:'60%', marginBottom:10 }} />
      <div className="skeleton" style={{ height:12, width:'40%', marginBottom:14 }} />
      <div style={{ display:'flex', justifyContent:'space-between' }}>
        <div className="skeleton" style={{ height:20, width:'35%' }} />
        <div className="skeleton" style={{ height:36, width:'30%', borderRadius:99 }} />
      </div>
    </div>
  </div>
);

export default PackageCard;
