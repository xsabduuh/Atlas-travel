import React from 'react';
import { useAuth } from '../context/AuthContext';
import './DestinationCard.css';

const DestinationCard = ({ destination, onWishlistClick, onBookClick }) => {
  const { isInWishlist, user } = useAuth();
  const inWishlist = isInWishlist(destination._id);

  const handleWishlist = (e) => {
    e.stopPropagation();
    onWishlistClick && onWishlistClick(destination._id, !inWishlist);
  };

  return (
    <div className="dest-card card">
      {/* Image area */}
      <div className="dest-img-wrap">
        {destination.image ? (
          <img
            src={destination.image}
            alt={destination.nameAr}
            className="dest-img"
            loading="lazy"
          />
        ) : (
          <div
            className="dest-img-placeholder"
            style={{ background: destination.bgColor || '#1a3a6e' }}
          >
            <span className="dest-emoji">{destination.emoji || '🌍'}</span>
            <span className="dest-flag-icon">{destination.flag}</span>
          </div>
        )}

        {/* Overlay gradient */}
        <div className="dest-overlay" />

        {/* Wishlist button */}
        <button
          className={`dest-wishlist ${inWishlist ? 'active' : ''}`}
          onClick={handleWishlist}
          aria-label={inWishlist ? 'إزالة من الأمنيات' : 'إضافة للأمنيات'}
        >
          {inWishlist ? '❤️' : '🤍'}
        </button>

        {/* Badge */}
        {destination.badge && (
          <div className="dest-badge-img">{destination.badge}</div>
        )}
      </div>

      {/* Info */}
      <div className="dest-info">
        <div className="dest-name">{destination.nameAr}</div>
        <div className="dest-country">
          {destination.flag} {destination.countryAr}
        </div>
        <div className="dest-rating-row">
          <span className="stars">★</span>
          <span className="dest-rating-val">{destination.rating?.toFixed(1)}</span>
          <span className="dest-reviews">({destination.reviewCount} تقييم)</span>
        </div>
        <div className="dest-footer">
          <div className="dest-price">
            <span className="price-from">من</span>
            <strong>{destination.priceFrom?.toLocaleString()}</strong>
            <span className="price-currency">درهم</span>
          </div>
          <span className="dest-duration">{destination.duration}</span>
        </div>
      </div>
    </div>
  );
};

// Skeleton version
export const DestinationCardSkeleton = () => (
  <div className="dest-card card">
    <div className="skeleton" style={{ height:180, borderRadius:'14px 14px 0 0' }} />
    <div style={{ padding:12 }}>
      <div className="skeleton" style={{ height:16, width:'70%', marginBottom:8 }} />
      <div className="skeleton" style={{ height:12, width:'50%', marginBottom:8 }} />
      <div className="skeleton" style={{ height:12, width:'40%' }} />
    </div>
  </div>
);

export default DestinationCard;
