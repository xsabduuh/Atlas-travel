# ✈️ Atlas Travel — Full Stack Travel Website

موقع سفر احترافي كامل مبني بـ React + Node.js + MongoDB

---

## 📁 هيكل المشروع

```
atlas-travel/
├── client/                  # React Frontend
│   ├── public/
│   │   └── index.html
│   └── src/
│       ├── components/      # مكونات قابلة لإعادة الاستخدام
│       │   ├── Navbar.js/css
│       │   ├── AuthModal.js/css
│       │   ├── DestinationCard.js/css
│       │   ├── PackageCard.js/css
│       │   ├── BookingForm.js/css
│       │   ├── SearchBar.js/css
│       │   └── Footer.js/css
│       ├── context/
│       │   └── AuthContext.js   # إدارة حالة المستخدم
│       ├── hooks/
│       │   └── useData.js       # Custom hooks للـ API
│       ├── utils/
│       │   └── api.js           # كل طلبات الـ API
│       ├── App.js               # الصفحة الرئيسية
│       ├── App.css
│       └── index.css            # Design System
│
└── server/                  # Node.js Backend
    ├── models/
    │   ├── User.js
    │   ├── Destination.js
    │   ├── Package.js
    │   └── Booking.js
    ├── routes/
    │   ├── auth.js
    │   ├── destinations.js
    │   ├── packages.js
    │   └── bookings.js
    ├── middleware/
    │   └── auth.js          # JWT middleware
    ├── server.js
    └── .env
```

---

## 🚀 خطوات التركيب

### 1. تحميل Node.js
```
https://nodejs.org/en/download
```

### 2. تحميل MongoDB
```
https://www.mongodb.com/try/download/community
```
أو استخدم MongoDB Atlas (مجاني):
```
https://www.mongodb.com/atlas
```

### 3. تثبيت المكتبات
```bash
# في مجلد atlas-travel
npm install

# تثبيت server
cd server
npm install

# تثبيت client
cd ../client
npm install
```

### 4. إعداد المتغيرات
في ملف `server/.env`:
```
PORT=5000
MONGODB_URI=mongodb://localhost:27017/atlas-travel
JWT_SECRET=your_secret_key_here
CLIENT_URL=http://localhost:3000
```

### 5. تشغيل المشروع
```bash
# تشغيل Server (من مجلد server)
cd server
npm run dev

# تشغيل Client (من مجلد client، في terminal آخر)
cd client
npm start
```

الموقع يفتح على: `http://localhost:3000`
API على: `http://localhost:5000`

---

## 🔌 API Endpoints

### Auth
| Method | URL | Description |
|--------|-----|-------------|
| POST | /api/auth/register | إنشاء حساب |
| POST | /api/auth/login | تسجيل الدخول |
| GET | /api/auth/me | بيانات المستخدم |
| POST | /api/auth/wishlist/:id | إضافة/إزالة من الأمنيات |

### Destinations
| Method | URL | Description |
|--------|-----|-------------|
| GET | /api/destinations | كل الوجهات |
| GET | /api/destinations/featured | الوجهات المميزة |
| GET | /api/destinations/:id | وجهة محددة |

### Packages
| Method | URL | Description |
|--------|-----|-------------|
| GET | /api/packages | كل الباقات |
| GET | /api/packages/featured | الباقات المميزة |
| GET | /api/packages/:id | باقة محددة |

### Bookings
| Method | URL | Description |
|--------|-----|-------------|
| POST | /api/bookings | إنشاء حجز |
| GET | /api/bookings/my | حجوزات المستخدم |
| GET | /api/bookings/:ref | تتبع حجز |

---

## 📸 إضافة الصور

ضع الصور في `client/public/images/` ثم استخدمها في الكود:

```css
/* Hero */
.hero-bg {
  background:
    linear-gradient(rgba(0,0,0,.45), rgba(0,0,0,.45)),
    url('/images/hero-bg.jpg') center/cover no-repeat;
}
```

أو في React:
```jsx
<img src="/images/istanbul.jpg" alt="إسطنبول" />
```

### الصور المطلوبة:
- `hero-bg.jpg` — صورة جوية لمدينة أو شاطئ (1920×1080)
- `istanbul.jpg` — الجامع الأزرق أو البوسفور
- `dubai.jpg` — برج خليفة أو الأفق
- `paris.jpg` — برج إيفل ليلاً
- `bali.jpg` — حقول الأرز أو معبد
- `rome.jpg` — الكولوسيوم
- `morocco.jpg` — مراكش أو الصحراء

---

## ⚡ الميزات

- ✅ تسجيل الدخول / إنشاء حساب (JWT)
- ✅ بحث متقدم عن الرحلات
- ✅ فلترة بالقارة والسعر
- ✅ Wishlist ❤️ للرحلات
- ✅ نظام حجز متكامل
- ✅ رقم مرجعي للحجز
- ✅ Responsive (جوال + تابلت + كمبيوتر)
- ✅ Skeleton loading أثناء التحميل
- ✅ Scroll reveal animations
- ✅ SEO meta tags
- ✅ MongoDB database
- ✅ REST API كاملة

---

## 🛠️ التقنيات المستخدمة

**Frontend:** React 18, CSS3, Flexbox/Grid  
**Backend:** Node.js, Express.js  
**Database:** MongoDB, Mongoose  
**Auth:** JWT (JSON Web Tokens)  
**Validation:** express-validator  

---

**Built with ❤️ by xsab.dev**
