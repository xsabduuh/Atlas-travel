const mongoose = require('mongoose');

const bookingSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  package: { type: mongoose.Schema.Types.ObjectId, ref: 'Package' },
  destination: { type: mongoose.Schema.Types.ObjectId, ref: 'Destination' },
  // Guest info (for non-logged in users)
  guestInfo: {
    name: { type: String, required: true },
    email: { type: String, required: true },
    phone: { type: String, required: true }
  },
  travelers: { type: Number, required: true, min: 1 },
  travelDate: { type: Date, required: true },
  destination_name: { type: String },
  budget: { type: String },
  notes: { type: String },
  totalPrice: { type: Number },
  status: {
    type: String,
    enum: ['pending', 'confirmed', 'cancelled', 'completed'],
    default: 'pending'
  },
  bookingRef: { type: String, unique: true }
}, { timestamps: true });

// Generate booking reference
bookingSchema.pre('save', function (next) {
  if (!this.bookingRef) {
    this.bookingRef = 'AT-' + Date.now().toString(36).toUpperCase();
  }
  next();
});

module.exports = mongoose.model('Booking', bookingSchema);
