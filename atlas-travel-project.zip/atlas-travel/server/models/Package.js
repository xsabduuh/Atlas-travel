const mongoose = require('mongoose');

const packageSchema = new mongoose.Schema({
  title: { type: String, required: true },
  titleAr: { type: String, required: true },
  destination: { type: mongoose.Schema.Types.ObjectId, ref: 'Destination' },
  cities: [String],
  citiesAr: [String],
  duration: { type: Number, required: true }, // days
  price: { type: Number, required: true },
  originalPrice: { type: Number },
  image: { type: String, default: '' },
  description: { type: String },
  descriptionAr: { type: String },
  includes: [String],
  excludes: [String],
  rating: { type: Number, default: 4.5 },
  reviewCount: { type: Number, default: 0 },
  badge: { type: String },
  badgeColor: { type: String, default: '#ff385c' },
  emoji: { type: String },
  bgColor: { type: String },
  featured: { type: Boolean, default: false },
  available: { type: Boolean, default: true },
  itinerary: [{
    day: Number,
    title: String,
    description: String
  }]
}, { timestamps: true });

module.exports = mongoose.model('Package', packageSchema);
