const mongoose = require('mongoose');

const destinationSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  nameAr: { type: String, required: true },
  country: { type: String, required: true },
  countryAr: { type: String, required: true },
  continent: {
    type: String,
    enum: ['asia', 'europe', 'middle-east', 'africa', 'americas', 'morocco'],
    required: true
  },
  image: { type: String, default: '' },
  description: { type: String },
  descriptionAr: { type: String },
  priceFrom: { type: Number, required: true },
  duration: { type: String },
  rating: { type: Number, default: 4.5, min: 1, max: 5 },
  reviewCount: { type: Number, default: 0 },
  badge: { type: String },
  featured: { type: Boolean, default: false },
  emoji: { type: String },
  flag: { type: String },
  bgColor: { type: String, default: '#1a3a6e' }
}, { timestamps: true });

module.exports = mongoose.model('Destination', destinationSchema);
