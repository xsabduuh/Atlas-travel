const express = require('express');
const router = express.Router();
const Destination = require('../models/Destination');
const auth = require('../middleware/auth');

// GET /api/destinations
router.get('/', async (req, res) => {
  try {
    const { continent, search, limit = 10, page = 1 } = req.query;
    const filter = {};
    if (continent && continent !== 'all') filter.continent = continent;
    if (search) {
      filter.$or = [
        { name: { $regex: search, $options: 'i' } },
        { nameAr: { $regex: search, $options: 'i' } },
        { country: { $regex: search, $options: 'i' } }
      ];
    }
    const total = await Destination.countDocuments(filter);
    const destinations = await Destination.find(filter)
      .skip((page - 1) * limit)
      .limit(Number(limit))
      .sort({ featured: -1, rating: -1 });

    res.json({ destinations, total, page: Number(page), pages: Math.ceil(total / limit) });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/destinations/featured
router.get('/featured', async (req, res) => {
  try {
    const destinations = await Destination.find({ featured: true }).limit(6);
    res.json(destinations);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/destinations/:id
router.get('/:id', async (req, res) => {
  try {
    const destination = await Destination.findById(req.params.id);
    if (!destination) return res.status(404).json({ message: 'Destination not found' });
    res.json(destination);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
