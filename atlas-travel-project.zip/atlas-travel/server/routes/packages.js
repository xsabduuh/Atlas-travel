const express = require('express');
const router = express.Router();
const Package = require('../models/Package');

// GET /api/packages
router.get('/', async (req, res) => {
  try {
    const { minPrice, maxPrice, duration, limit = 10, page = 1 } = req.query;
    const filter = { available: true };
    if (minPrice || maxPrice) {
      filter.price = {};
      if (minPrice) filter.price.$gte = Number(minPrice);
      if (maxPrice) filter.price.$lte = Number(maxPrice);
    }
    if (duration) filter.duration = { $lte: Number(duration) };

    const total = await Package.countDocuments(filter);
    const packages = await Package.find(filter)
      .populate('destination', 'name nameAr country flag')
      .skip((page - 1) * limit)
      .limit(Number(limit))
      .sort({ featured: -1, rating: -1 });

    res.json({ packages, total, page: Number(page), pages: Math.ceil(total / limit) });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/packages/featured
router.get('/featured', async (req, res) => {
  try {
    const packages = await Package.find({ featured: true, available: true })
      .populate('destination', 'name nameAr flag')
      .limit(4);
    res.json(packages);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/packages/:id
router.get('/:id', async (req, res) => {
  try {
    const pkg = await Package.findById(req.params.id).populate('destination');
    if (!pkg) return res.status(404).json({ message: 'Package not found' });
    res.json(pkg);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
